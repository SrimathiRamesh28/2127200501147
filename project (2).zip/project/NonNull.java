package com.example.project;

public @interface NonNull {
}
